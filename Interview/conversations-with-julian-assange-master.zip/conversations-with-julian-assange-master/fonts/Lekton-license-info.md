# Licensing info for Lekton

Lekton
Version 34.000

Copyright (c) 2008, 2009, 2010, Accademia di Belle Arti di Urbino. Licensed under the SIL Open Font License, Version 1.1


