images > dummy
==============

About the images:

* 29072011-247.jpg* 29072011-248.jpg* 29072011-249.jpg

Dummy print of a volume gathering interviews and essays on Assange. This volume was not publicly released, as the editor (Greyscale Press) did not obtain the publishing agreements of the involved authors.

* * *